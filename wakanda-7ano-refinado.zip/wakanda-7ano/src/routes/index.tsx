import { createFileRoute } from "@tanstack/react-router";

import pantherImg from "@/assets/wakanda-pantera.png";

import pantherSolo from "@/assets/wakanda-pantera-solo.png";

const pantherAsset = { url: pantherImg };

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "WAKANDA — 7º Ano | Jogos Internos" },
      {
        name: "description",
        content: "Conheça a WAKANDA, equipe do 7º Ano nos Jogos Internos: força, união e coragem.",
      },
      { property: "og:title", content: "WAKANDA — 7º Ano | Jogos Internos" },
      {
        property: "og:description",
        content: "A identidade oficial da equipe WAKANDA do 7º Ano nos Jogos Internos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const values = ["Força", "Velocidade", "União", "Coragem"];
const steps = ["ml-0", "ml-[7%]", "ml-[2%]", "ml-[13%]"];
const cut = "[clip-path:polygon(0_0,100%_0,100%_calc(100%-14px),calc(100%-14px)_100%,0_100%)]";

function Index() {
  return (
    <main className="overflow-hidden bg-background text-foreground">
      <header className="absolute inset-x-0 top-0 z-30">
        <div className="flex h-20 items-center justify-between px-5 lg:px-8">
          <a href="#inicio" className="font-display text-2xl font-black uppercase" aria-label="WAKANDA, início">
            Wakanda <span className="text-primary">7</span>
          </a>
          <nav className="flex items-center gap-6 text-sm font-semibold sm:gap-9" aria-label="Navegação principal">
            <a className="hover:text-primary" href="#identidade">Quem somos</a>
            <a className="hover:text-primary" href="#mascote">A pantera</a>
            <a className="hidden hover:text-primary sm:inline" href="#setimo">7º ano</a>
          </nav>
        </div>
      </header>

      {/* HERO: a pantera ocupa o topo e as garras tocam o nome, como na logo */}
      <section id="inicio" className="relative flex min-h-[100svh] flex-col justify-end pb-10 pt-24">
        <div className="pointer-events-none relative mx-auto w-full max-w-[880px] animate-rise">
          <img
            src={pantherSolo}
            alt="Pantera negra da equipe WAKANDA, com olhos azuis e garras sobre o nome"
            className="w-full"
          />
        </div>
        <div className="relative z-10 -mt-[5vw] px-5 lg:px-8">
          <h1 className="-skew-x-6 whitespace-nowrap font-display text-[clamp(3.4rem,23.5vw,22rem)] font-black uppercase leading-[0.8]">
            Wakanda
          </h1>
          <div className="mt-2 flex flex-wrap items-end justify-between gap-x-10 gap-y-6">
            <p className="-skew-x-6 font-display text-[clamp(3.6rem,11vw,9rem)] font-black uppercase leading-[0.85] text-primary">
              7º Ano
            </p>
            <div className="flex flex-col items-start gap-5 pb-2 sm:items-end">
              <p className="font-display text-xl font-bold uppercase sm:text-2xl">Jogos Internos 2026</p>
              <a
                href="#identidade"
                className={`${cut} bg-primary px-8 py-3 font-display text-lg font-extrabold uppercase text-primary-foreground hover:bg-primary-strong focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-foreground`}
              >
                Conheça a equipe
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* IDENTIDADE: único bloco claro, palavras empilhadas em vez de cards */}
      <section id="identidade" className="relative -mt-[4vw] bg-paper pb-24 pt-[calc(4vw+5rem)] text-ink [clip-path:polygon(0_4vw,100%_0,100%_100%,0_100%)] sm:pb-32">
        <svg className="pointer-events-none absolute -right-6 top-[18%] h-[70%] opacity-100" viewBox="0 0 260 500" fill="var(--primary)" aria-hidden="true">
          <polygon points="150,0 178,0 40,500 0,500" />
          <polygon points="90,60 112,60 40,500" transform="translate(120 -10)" />
          <polygon points="210,140 232,140 190,500 170,500" />
        </svg>
        <div className="relative mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-[minmax(0,26rem)_1fr] lg:gap-20 lg:px-8">
          <div className="lg:pt-6">
            <h2 className="font-display text-3xl font-black uppercase">Quem somos</h2>
            <p className="mt-5 text-lg leading-relaxed text-ink/80">
              Wakanda é a equipe do 7º ano nos Jogos Internos. Entramos em quadra para competir, superar desafios e representar a nossa turma com a mesma determinação da pantera negra.
            </p>
          </div>
          <ul className="relative z-10 font-display text-[clamp(3.4rem,12.5vw,10.5rem)] font-black uppercase leading-[0.86]">
            {values.map((v, i) => (
              <li key={v} className={`${steps[i]} -skew-x-6`}>{v}</li>
            ))}
          </ul>
        </div>
      </section>

      {/* MASCOTE: close no rosto, sangrando para fora da tela */}
      <section id="mascote" className="relative pb-[calc(4vw+5rem)] pt-24 sm:pt-32">
        <div className="mx-auto grid max-w-7xl items-center gap-10 lg:grid-cols-[0.8fr_1.2fr]">
          <img
            src={pantherAsset.url}
            alt="Logo oficial da WAKANDA 7º ano: pantera negra com detalhes azuis"
            className="mx-auto w-full max-w-[460px] px-5 mix-blend-screen lg:ml-8 lg:max-w-[520px] lg:px-0"
          />
          <div className="px-5 lg:px-8 lg:pr-12">
            <h2 className="-skew-x-6 font-display text-[clamp(4.5rem,13vw,10rem)] font-black uppercase leading-[0.82]">
              A pantera
            </h2>
            <p className="mt-8 max-w-md text-xl leading-relaxed text-foreground/75">
              Silenciosa quando precisa ser, rápida quando chega a hora e feroz diante do desafio. É assim que a Wakanda joga.
            </p>
          </div>
        </div>
      </section>

      {/* 7: o único bloco chapado em azul */}
      <section id="setimo" className="relative -mb-[4vw] -mt-[4vw] bg-primary pb-[calc(4vw+4rem)] pt-[calc(4vw+4rem)] text-primary-foreground [clip-path:polygon(0_4vw,100%_0,100%_calc(100%-4vw),0_100%)]">
        <div className="mx-auto grid max-w-7xl items-end gap-4 px-5 lg:grid-cols-[auto_1fr] lg:gap-16 lg:px-8">
          <p className="-skew-x-6 font-display text-[clamp(14rem,40vw,30rem)] font-black leading-[0.7]" aria-hidden="true">7</p>
          <div className="pb-2">
            <p className="font-display text-2xl font-extrabold uppercase sm:text-4xl">Não é apenas uma turma.</p>
            <h2 className="-skew-x-6 font-display text-[clamp(3.6rem,10vw,8rem)] font-black uppercase leading-[0.88]">É uma equipe.</h2>
            <p className="mt-6 max-w-lg text-lg font-medium leading-relaxed">
              Cada voz, cada esforço e cada disputa carregam o mesmo nome. O 7º ano entra unido para deixar sua marca nos Jogos Internos.
            </p>
          </div>
        </div>
      </section>

      <section className="px-5 pb-20 pt-[calc(4vw+5rem)] lg:px-8">
        <p className="-skew-x-6 font-display text-[clamp(3.4rem,14vw,12rem)] font-black uppercase leading-[0.85]">
          A quadra<br />é nossa.
        </p>
      </section>

      <footer className="border-t border-border">
        <div className="flex flex-col gap-2 px-5 py-7 font-display text-lg font-bold uppercase sm:flex-row sm:justify-between lg:px-8">
          <span>Wakanda <span className="text-primary">7º Ano</span></span>
          <span className="text-muted-foreground">Jogos Internos 2026</span>
        </div>
      </footer>
    </main>
  );
}
