# WAKANDA — 7º Ano | Jogos Internos

Código-fonte completo da landing page oficial da equipe WAKANDA (7º Ano), construído em
TanStack Start + React 19 + TypeScript + Tailwind CSS v4.

## Como rodar no seu computador

Pré-requisito: Node.js 20 ou mais novo.

```sh
npm install
npm run dev
```

Abra o endereço que aparecer no terminal (geralmente `http://localhost:8080`).

Outros comandos:

| Comando | O que faz |
| --- | --- |
| `npm run dev` | abre o site em modo desenvolvimento |
| `npm run build` | gera a versão final em `dist/` |
| `npm run preview` | serve a versão final gerada |
| `npm run lint` | verifica a qualidade do código |
| `npm run test` | roda os testes |

## Onde está cada coisa

- `src/routes/index.tsx` — a página inteira: cabeçalho, primeira tela, "Nossa Identidade",
  "A Pantera", "7º Ano", faixa final e rodapé.
- `src/routes/__root.tsx` — título da aba, descrição para busca e compartilhamento, fontes.
- `src/styles.css` — todas as cores, fontes e animações do site (tokens centrais).
- `src/components/ui/` — componentes prontos (botões e afins).
- `src/assets/` — a logo da pantera.

## Ajuste importante ao usar fora da Lovable

Dentro da Lovable a pantera é carregada por um ponteiro de arquivo hospedado
(`src/assets/wakanda-pantera.png.asset.json`, campo `url`). Fora da Lovable esse endereço não
existe, então use a cópia local que já vem no pacote:

Em `src/routes/index.tsx`, troque

```tsx
import pantherAsset from "@/assets/wakanda-pantera.png.asset.json";
```

por

```tsx
import pantherImg from "@/assets/wakanda-pantera.png";
const pantherAsset = { url: pantherImg };
```

O resto do código continua igual — `pantherAsset.url` passa a apontar para o arquivo local.

## Identidade visual (regras fixas)

- Paleta: preto profundo, preto azulado, azul-marinho, azul elétrico como destaque estratégico,
  off-white. Sem roxo, vermelho, verde, neon, gradientes exagerados ou textura de tecido/fotografia.
- Tipografia: Barlow Condensed (títulos) e Barlow (texto), via Google Fonts.
- A pantera fornecida é o mascote oficial e o elemento central: nunca redesenhá-la.
- Texto das seções "Nossa Identidade", "A Pantera" e a frase "Força. União. Coragem." são exatos
  e devem ser preservados.

## Estrutura

```
src/
  routes/
    __root.tsx      metadados, fontes, layout raiz
    index.tsx       a landing page completa
  components/ui/    componentes de interface
  styles.css        cores, fontes, animações
  assets/           pantera (PNG + ponteiro hospedado)
public/
  favicon.ico
  robots.txt
```
